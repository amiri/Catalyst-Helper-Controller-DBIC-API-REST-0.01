package # hide from PAUSE 
    RestTest::Schema::ResultSet;

use strict;
use warnings;

use parent qw/DBIx::Class::ResultSet/;

1;
