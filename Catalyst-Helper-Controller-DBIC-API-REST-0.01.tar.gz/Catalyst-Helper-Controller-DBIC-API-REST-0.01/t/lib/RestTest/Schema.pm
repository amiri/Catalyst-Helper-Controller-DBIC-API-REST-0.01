package # hide from PAUSE
    RestTest::Schema;

use base qw/DBIx::Class::Schema/;

no warnings qw/qw/;

__PACKAGE__->load_namespaces;

1;
